<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\RegistrationRequest;
use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Auth;

class RegistrationController extends Controller
{
    public function registration(RegistrationRequest $request){
        $fall_name = $request->first_name." ".$request->last_name;

        User::create([
           'first_name' => $request->first_name,
           'last_name' => $request->last_name,
            'full_name' => $fall_name,
            'date' => $request->date,
            'email' => $request->email,
            'password' => $request->password,
            'phone_number' => $request->phone_number,
        ]);

        return response()->json([
            'status'=>true,
            'message'=>'User registred'
        ],200);
    }

    public function login(LoginRequest $request){

        $user_data = $request->only(['phone_number', 'password']);

        $user = User::where('phone_number',$request->phone_number)
                    ->where('password',$request->password)
                    ->first();

        if (auth('api')->attempt(['phone_number' => $request->phone_number, 'password' => $request->password])) {
           return response()->json([
               'status'=>true,
               'message'=>'user authenticated'
            ],200);
        }
    }

}
