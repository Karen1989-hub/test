<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\news;

class NewsController extends Controller
{
    public function get_news(){
        $news = News::with('get_comment')->simplePaginate(10);

        return response()->json([
            'status'=>true,
            'data'=>$news,
        ],200);

    }

    public function add_news(Request $request){

        try {
            $result = News::create(['title'=>$request->title,'text'=>$request->text]);

            return response()->json([
                'status'=>true,
                'message'=>'news added'
            ],200);
        } catch (\Exception $e) {
            return response()->json([
                'status'=>false,
                'message'=>'server error'
            ],500);
        }

    }

    public function update_new(Request $request){

       $update_news = News::find($request->news_id);
       if($request->title){
           $update_news->title = $request->title;
       }
        if($request->text){
            $update_news->text= $request->text;
        }
        $update_news->save();

        return response()->json([
            'status'=>true,
            'message'=>'news updated'
        ],200);

    }

    public function delete_news(Request $request){

        try{
            News::where('id',$request->news_id)->delete();

            return response()->json([
                'status'=>true,
                'message'=>'news deleted'
            ],200);
        } catch (\Exception $e){
            return response()->json([
                'status'=>false,
                'message'=>'server error'
            ],500);
        }

    }
}
