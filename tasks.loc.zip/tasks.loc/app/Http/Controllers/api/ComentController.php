<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Coment;
use Illuminate\Http\Request;

class ComentController extends Controller
{
    public function add_comment(Request $request){
        $user_id = auth()->guard('api')->user()->id;
        $user_name = User::select('full_name')->find($user_id);
        $news_id = $request->news_id;

        try{
            $result = Coment::create([
                'news_id'=>$news_id,
                'comment'=>$request->comment,
                'user_name'=>$user_name
            ]);
            return response()->json([
                'status'=>true,
                'message'=>'comment added'
            ],200);
        } catch (\Exception $e){
            return response()->json([
                'status'=>false,
                'message'=>'server error'
            ],500);
        }

    }


}
